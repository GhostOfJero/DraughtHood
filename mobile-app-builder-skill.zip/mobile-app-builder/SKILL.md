---
name: mobile-app-builder
description: "Plan, design, implement, validate, and hand off mobile apps with Manus WebDev's managed Expo/React Native/TypeScript starter. Use when creating or extending a managed native mobile app, including offline-first products, games, Preview verification, Android APK sideload readiness, and project checkpoints."
---

# Mobile App Builder

Use this workflow for new or existing **Manus-managed Mobile** projects. It covers general apps and games; adapt product architecture to the request. The authoritative platform contracts remain in `/home/ubuntu/skills/webdev/SKILL.md` and `/home/ubuntu/skills/webdev/templates/expo/README.md`. Read those, plus only the capability guides needed by the request. Do not copy their full contracts into this skill.

## 1. Choose the right project path

1. For a new or existing mobile app request, follow `/home/ubuntu/skills/webdev/worklocally/SKILL.md` before initialization. Resolve the managed-Mobile-versus-plain-local choice when it is not already answered. **Managed Mobile runs in Manus Cloud**; explain that environment change before asking. Wait for the user's choice before switching or initializing. If the user chooses plain local, stay local and use their chosen toolchain; do not use the managed Expo restrictions, WebDev checkpoint push, or app services.
2. For managed Mobile, verify the selected Cloud environment and project identity. Attach an explicitly selected existing app instead of creating another. Preserve the returned project directory and initialization decisions.
3. Initialize once with `applicationKind: "mobile_app"`. The starter fixes Expo Router, React Native, TypeScript, NativeWind, Express/tRPC/Drizzle, runtime ports, and managed capabilities. Do not pass Web-only feature, framework, template, or port choices; do not replace or regenerate the starter. If setup presents a Blueprint/model choice, wait for that decision and then call `webdev.config` `GET init/continue`; do not initialize again.
4. If the app needs an external connector or provider, inspect current connector configuration with `manus-config config load`, reuse a matching enabled connector, and follow the relevant guide. Do not add integrations, credentials, or backend services for a feature that works locally.

## 2. Plan the product before coding

1. Translate the request into concrete user journeys, screens, state transitions, constraints, and independently deliverable outcomes. Clarify choices that would materially change product behavior; choose reversible visual and implementation details directly.
2. Read the Expo README and all task-relevant WebDev capability guides before planning. Inspect the actual starter, package scripts, and installed dependencies; prefer existing libraries and conventions.
3. Record implementation and design decisions in the project's `plan.md` when Plan Mode or the project workflow requires it. Ground the structure in actual project files and describe the responsibilities of `app/`, `components/`, `lib/`, `hooks/`, `assets/`, `server/`, `drizzle/`, and `tests/` as applicable. State which features are local, which use the backend, and why.
4. Give the app a coherent visual system, not just a color list: define aesthetic reference, 3–4 core principles, palette rationale, phone-first layout, recurring motifs, touch/interaction behavior, animation, typography, brand positioning/voice, and logo direction. Respect supplied references and user assets. Design each screen for portrait phones and practical one-handed use.
5. Before implementation, create outcome-based native TODO items when available; otherwise use `TODO.md`. Preserve the user's actual acceptance language and explicit values, actors, transitions, and exceptions. Group independent outcomes, do not turn each requirement into a test task, and mark items complete only when there is evidence.

## 3. Prepare assets and diagnostics

1. Reuse user-supplied assets where suitable. Generate only planned custom visuals, with explicit placement/composition; continue independent work while an asynchronous generation runs and do not poll or resubmit it. Keep generated visual assets in the project when the native app must bundle them.
2. Before the first application-code batch, inspect `webdev.config` `GET runtime/post-edit`. Confirm TypeScript diagnostics are registered. The Sandbox host manages this LSP; do not start a duplicate server. Resolve actionable diagnostics and still run the project's check command.
3. Treat platform branding, native launcher icons, and in-app art as separate outputs. Before checkpointing application work, provide the complete square native icon/adaptive foreground/background/monochrome and splash/favicon assets required by the Expo README, update references in `app.config.ts`, and preserve `appSlug`, scheme, and generated bundle identifiers. Set a quoted, durable HTTPS `logoUrl` literal in root `app.config.ts` using the WebDev logo contract; this platform logo does not replace native assets. Never use a relative or temporary signed URL for `logoUrl`.
4. Add dependencies only when necessary. Follow the dependency-setup guide, preserve the lockfile, and install only when packages are missing or intentionally added.

## 4. Implement with clear mobile boundaries

1. Keep Expo Router navigation in `app/`, reusable React Native views in `components/`, domain logic in focused `lib/` modules, persisted state in a separate store, and tests in `tests/`. Avoid concentrating an entire product in one screen file.
2. Implement the domain layer independently of React where practical. For games, keep rules, legal actions, opponent strategy, and challenge definitions pure and separately testable. For other products, isolate validation, calculations, or state transitions the same way.
3. Use React Native primitives and the starter's NativeWind conventions. In this starter, style `Pressable` containers with `style`/`StyleSheet` (not `className`); keep Web DOM code behind a platform boundary. Add accessible labels/states to controls, visible focus/selection, touch-sized actions, and concise empty/loading/error states.
4. Default to offline-first behavior when no network is necessary. Persist settings, local profiles, and resumable state with the starter's AsyncStorage pattern; normalize old/missing fields when evolving saved data. Keep secrets off the client. Add database, authentication, realtime service, or server routes only when required by the agreed product.
5. Make animations reflect the product's visual system: short purposeful transitions, no unnecessary perpetual motion, and reduced-motion support where practical. Use haptics/audio only when useful, guard unavailable native APIs, and request no permissions the app does not need.
6. Keep the fixed managed-Mobile runtime: Metro on `8081`, API on `3000`, platform-provided Expo/Preview URLs, and canonical Manus-managed Git. Do not change ports or hardcode session-dependent preview hosts. Do not add website-only routing, SEO, or PWA requirements to a native app unless separately requested.

## 5. Start and verify the app

1. Use finite checks such as `pnpm check` and `pnpm test` before relying on a live screen. Run database synchronization with `pnpm db:push` successfully before the starter's first OAuth/API traffic; after reattachment, repeat it only for a changed migration or missing schema.
2. Inspect the existing listeners and start only what is missing, from the exact project directory, as a resident service:
   - both Metro and API missing: `pnpm dev`
   - Metro `8081` only missing: `pnpm dev:metro`
   - API `3000` only missing: `pnpm dev:server`
   Use `service=true`, never set CI mode for Metro, and verify both listeners with HTTP checks. Reuse healthy services and restore dependencies only when actually missing.
3. Prefer code inspection, TypeScript diagnostics, and deterministic tests. Use Preview/browser/screenshot checks only when the user requests visual review or when needed to investigate a concrete issue; test the critical interaction that matters, not every screen by default. A Web Preview does not verify native-only behavior such as haptics, device storage, camera, or deep links. Use an actual device/Expo Go check for requested native-only behavior or state the limitation.
4. For a complex feature set, use one read-only shared validation agent to compare implementation with the original acceptance clauses and trace module connections. Supply the project directory, plan/TODO, relevant platform facts, and existing evidence. Fix confirmed issues and recheck only affected paths.
5. Update TODO status only with evidence. Report test totals accurately, including skipped tests and any native-only checks not performed.

## 6. Prepare builds and hand off safely

1. For Android sideloading, add or merge an internal APK build profile in `eas.json` (for example, `distribution: "internal"` and `android.buildType: "apk"`). Preserve existing profiles. Do not claim an APK exists merely because the configuration is present.
2. Native Android/iOS artifacts are built through the WebDev Dashboard from accepted source/configuration. **Do not run Android/iOS release builds in Sandbox or inside the resident Metro process.** Expo Go connection and credentials follow the Expo README: use Dashboard flows, never print or request a build credential in chat.
3. Before saving a managed project version, reuse the known `publishing.auto_publish` state; never enable auto-publish. Fetch `origin/main`, integrate remote changes without rewriting history, run affected checks, commit intended files, and push to canonical `origin/main`. Confirm the intended commit SHA in Version History/checkpoint evidence; a local commit or successful push alone is not checkpoint confirmation. Do not force-push.
4. Keep checkpointing distinct from publication. A Preview or checkpoint is not a published app. If publication is not confirmed, deliver the current Preview and label it as such. Summarize what was built, validation performed, material limitations, and whether a native APK was actually produced. Provide the project/Preview link; attach files only when they are the requested deliverable.
